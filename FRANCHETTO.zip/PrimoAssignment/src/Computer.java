public class Computer {
    //attributi
    private int idComputer;
    private Persona user; //utilizzatore
    private Casa marca;
    private int valore;
    private int quantiUser;
    private static int computerCostruiti = 0; //attributo di classe, all'inizio è 0

    //costruttore che non assegna user;
    public Computer(int idComputer, Casa marca, int valore, int quantiUser) {
        this.idComputer = idComputer; //int
        this.marca = marca; //String
        this.valore = valore; //int
        //non sono sicura che la parte sottostante vada inserita dato che il costruttore non assegna utilizzatore:
        computerCostruiti++; //così quando si costruisce un nuovo computer il conteggio aumenta di 1

    }

    //getter
    public int getIdComputer() {
        return this.idComputer;
    }

    public Persona getUser(){
        return this.user;
    }
    public Casa getMarca() {
        return this.marca;
    }

    public int getValore() {
        return this.valore;
    }
    public int getQuantiUser() {
        return this.quantiUser;
    }

    public static int getComputerCostruiti(){
        return computerCostruiti;
    }

    //setter - tranne identificativo(idComputer) e n. utilizzatori (quantiUser);
    public static void setComputerCostruiti(int computerCostruiti) {
        Computer.computerCostruiti = computerCostruiti;
    }

    public void setMarca(Casa marca) {
        this.marca = marca;
    }

    public void setUser(Persona user) {

        this.user = user;
        quantiUser++;
    } //non sicura di dover mettere "quantiUser++"

    public void setValore(int valore) {
        this.valore = valore;
    }

    // aumentare valore
    public void aumenta (int x) {
        this.valore = this.valore + x;
    }

    // diminuire valore
    public void riduci (int x) {
        if (x < this.valore) {           //così valore non va sotto 0
            this.valore = this.valore - x;
        }
    }

    //per cambiare l'utilizzatore
    public void cambia (Persona nuovoUser) {
        this.user = nuovoUser;
        quantiUser++; // così se cambi l'user se ne aggiunge uno
    }

    // conteggio dei computer che sono stati creati
    public static int conta(int computerCostruiti) {
        return computerCostruiti;
    }

    //metodo privato per aumentare di 1 il numero di utilizzatori
    private void aumentaUser() {
        quantiUser++;

    }

}
