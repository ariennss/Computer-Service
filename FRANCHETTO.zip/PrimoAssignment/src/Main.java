// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
    //prova per vedere se funziona la classe Persona
        Persona persona1 = new Persona(111, "Franchetto", "Via Roma 10");
        System.out.println(persona1.getCognome());

        Persona persona2 = new Persona (222, "Rossi");
        persona2.setIndirizzo("Via Torino 15");
        System.out.println(persona2.getIndirizzo());

        Persona persona3 = new Persona(333, "Verdi", "Via Milano 20");


    //prova per vedere se funziona la classe Casa
        Casa casa1 = new Casa("Lenovo", "Cina" );
        Casa casa2 = new Casa ("Samsung", "Corea");
        Casa casa3 = new Casa ("Acer");

        System.out.println(casa1.getNome());
        casa3.setNazione("Taiwan");
        System.out.println(casa3.getNazione());

    //prova per vedere se funziona la classe Computer
        Computer computer1 = new Computer(66666, casa1,300, 0);
        System.out.println(computer1.getIdComputer());

    //i metodi aumenta/riduci funzionano
        computer1.riduci(20);
        System.out.println(computer1.getValore());





    }
}