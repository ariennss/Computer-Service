// classe Persona

public class Persona {

    //attributi
    private int id;
    private String cognome;
    private String indirizzo;

    //costruttori
    public Persona (int id, String cognome, String indirizzo) {
        this.id = id;
        this.cognome = cognome;
        this.indirizzo = indirizzo;
    }

    public Persona(int id, String cognome) {
        this.id = id;
        this.cognome = cognome;
        this.indirizzo = " ";
    }

    //get id
    public int getId() {
        return id;
    }

    //get cognome
    public String getCognome() {
        return cognome;
    }

    //get indirizzo
    public String getIndirizzo() {
        return indirizzo;
    }

    //set indirizzo
    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }
}
