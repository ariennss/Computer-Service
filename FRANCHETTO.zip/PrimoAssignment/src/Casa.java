// classe Casa Produttrice di computer

public class Casa {

    //attributi
    private String nome;
    private String nazione;

    //costruttori
    public Casa (String nome) {
        this.nome = nome;
        this.nazione = " ";
    }

    public  Casa (String nome, String nazione) {
        this.nome = nome;
        this.nazione = nazione;
    }

    //getter
    public String getNome() {
        return this.nome;
    }

    public String getNazione() {
        return this.nazione;
    }

    //setter
    public void setNazione(String nazione) {
        this.nazione = nazione;
    }
}
